package module_3;
import java.util.Scanner;

public class module_3 {
   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      double weeklyIncome;
      double taxRate;
      double taxWithholding;

      System.out.print("Enter your weekly income: ");
      weeklyIncome = scnr.nextDouble();

      if (weeklyIncome < 500) {
         taxRate = 0.10;
      } else if (weeklyIncome >= 500 && weeklyIncome < 1500) {
         taxRate = 0.15;
      } else if (weeklyIncome >= 1500 && weeklyIncome < 2500) {
         taxRate = 0.20;
      } else {
         taxRate = 0.30;
      }

      taxWithholding = weeklyIncome * taxRate;

      System.out.println("$" + taxWithholding);
      scnr.close();
   }
}
