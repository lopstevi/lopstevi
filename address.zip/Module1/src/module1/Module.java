package module1;

public class Module {

	public static void main(String[] args) {
		System.out.println("Stewie");
		System.out.println("Popez");
		System.out.println("9999 Tarpuni Pl.");
		System.out.println("Bas Begas, NV");
		System.out.println("89999");

	}

}
